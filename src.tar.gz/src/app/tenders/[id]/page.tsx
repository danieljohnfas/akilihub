import { db, safeQuery } from '@/lib/db/client';
import { tenders, tenderSectors } from '@/lib/db/schema/tenders';
import { countries } from '@/lib/db/schema/shared';
import { eq } from 'drizzle-orm';
import { notFound } from 'next/navigation';
import { Calendar, Building2, MapPin, DollarSign, ExternalLink, ArrowLeft, Download, FileText } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { buttonVariants } from '@/components/ui/button';
import { format } from 'date-fns';
import Link from 'next/link';

import { AutoLinker } from '@/components/seo/AutoLinker';
import { JsonLd } from '@/components/seo/JsonLd';
import { buildTenderSchema, buildBreadcrumbSchema } from '@/components/seo/schemas';
import { isGeneratedSlug } from '@/lib/utils';
import { getSourceProvenance } from '@/lib/utils/provenance';
import type { Metadata } from 'next';

// ISR: revalidate every hour. Avoids Googlebot seeing inconsistent content
// across multiple crawls (which triggers "Google chose different canonical").
export const revalidate = 3600;

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const resolvedParams = await params;
  const data = await safeQuery(
    db
      .select({
        title: tenders.title,
        authority: tenders.contractingAuthority,
        description: tenders.description,
        country: countries.name,
        publishedAt: tenders.publishedAt,
        status: tenders.status,
        deadline: tenders.deadline,
      })
      .from(tenders)
      .leftJoin(countries, eq(tenders.countryId, countries.id))
      .where(eq(tenders.id, resolvedParams.id))
      .limit(1)
  );

  if (!data.length) {
    return { 
      title: 'Tender Not Found',
      robots: { index: false, follow: false }
    };
  }

  const tender = data[0];
  const title = `${tender.title} | AkiliBrain Procurement`;
  const desc = tender.description
    ? (tender.description.slice(0, 150) + (tender.description.length > 150 ? '...' : ''))
    : `Government tender by ${tender.authority} in ${tender.country || 'East Africa'}.`;
  
  const url = `https://akilibrain.com/tenders/${resolvedParams.id}`;

  // A tender is closed if its status is non-open OR its deadline has passed.
  const isClosed =
    tender.status !== 'open' ||
    (tender.deadline != null && tender.deadline < new Date());

  return {
    title,
    description: desc,
    keywords: [tender.title, tender.authority, tender.country || '', 'tender', 'procurement'].filter(Boolean),
    openGraph: {
      title,
      description: desc,
      url,
      type: 'article',
      ...(tender.publishedAt && { publishedTime: tender.publishedAt.toISOString() }),
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description: desc,
    },
    alternates: {
      canonical: url,
    },
    // Closed/awarded/cancelled tenders are dead content — noindex prevents
    // Google from flagging canonical conflicts when status changes mid-crawl.
    ...(isClosed && {
      robots: {
        index: false,
        follow: false,
      },
    }),
  };
}

export default async function TenderDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const resolvedParams = await params;
  
  const data = await safeQuery(db
    .select({
      tender: tenders,
      country: countries.name,
      sector: tenderSectors.name,
    })
    .from(tenders)
    .leftJoin(countries, eq(tenders.countryId, countries.id))
    .leftJoin(tenderSectors, eq(tenders.sectorId, tenderSectors.id))
    .where(eq(tenders.id, resolvedParams.id))
    .limit(1));

  if (!data.length) {
    notFound();
  }

  const { tender, country, sector } = data[0];
  const isExpired = tender.deadline ? tender.deadline < new Date() : false;
  const targetUrl = tender.employerUrl ?? tender.sourceUrl;
  const provenance = getSourceProvenance(targetUrl, 'tender');

  return (
    <div className="container py-8 max-w-4xl mx-auto space-y-8">
      {/* Back Button */}
      <Link href="/tenders" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Tenders
      </Link>

      {/* JSON-LD Schema */}
      <JsonLd schema={buildTenderSchema({
        id: tender.id,
        title: tender.title,
        description: tender.description,
        contractingAuthority: tender.contractingAuthority,
        country,
        sector,
        status: tender.status,
        deadline: tender.deadline,
        publishedAt: tender.publishedAt,
        budget: tender.budget,
        currency: tender.currency
      })} />
      <JsonLd schema={buildBreadcrumbSchema([
        { name: 'Home', url: 'https://akilibrain.com' },
        { name: 'Procurement Directory', url: 'https://akilibrain.com/tenders' },
        { name: tender.title, url: `https://akilibrain.com/tenders/${tender.id}` },
      ])} />

      {/* Header */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-3">
          <Badge variant="outline" className={`text-xs border ${provenance.badgeClassName}`}>
            {provenance.badgeLabel}
          </Badge>
          {!isGeneratedSlug(tender.referenceNo) ? (
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
              {tender.referenceNo}
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
              Tender Notice
            </Badge>
          )}
          <Badge 
            variant={tender.status === 'open' && !isExpired ? 'default' : 'secondary'}
            className={tender.status === 'open' && !isExpired ? 'bg-emerald-500/20 text-emerald-400' : ''}
          >
            {isExpired ? 'Expired' : tender.status.toUpperCase()}
          </Badge>
          {sector && (
            <Badge variant="secondary" className="bg-white/5">
              {sector}
            </Badge>
          )}
        </div>
        
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground leading-tight">
          {tender.title}
        </h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="md:col-span-2 space-y-8">
          <section className="space-y-4 bg-white/5 border border-white/10 rounded-xl p-6 backdrop-blur-sm">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" />
              Description
            </h2>
            <div className="prose prose-invert max-w-none text-muted-foreground">
              {tender.description ? (
                <AutoLinker text={tender.description} className="whitespace-pre-wrap" />
              ) : (
                <p className="italic">No detailed description provided by the authority.</p>
              )}
            </div>
          </section>

          <section className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white/5 border border-white/10 rounded-xl p-4 flex flex-col justify-center">
              <p className="text-sm text-muted-foreground mb-1">Published Date</p>
              <p className="font-medium flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" />
                {tender.publishedAt ? format(tender.publishedAt, 'PPP') : 'N/A'}
              </p>
            </div>
          </section>

          {/* Editorial Context — Google AdSense content quality requirement */}
          <section className="space-y-3 bg-white/5 border border-white/10 rounded-xl p-6 backdrop-blur-sm">
            <h2 className="text-lg font-semibold text-foreground">About This Tender</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              This procurement notice was sourced by AkiliBrain from a publicly accessible government
              portal or official procurement authority. AkiliBrain&apos;s pipelines refresh daily to
              ensure listings reflect current status. Open tenders are indexed; closed or expired tenders
              are automatically de-listed.
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              AkiliBrain does not charge contracting authorities for listing and is not affiliated with
              any procurement body. Businesses should verify all tender details directly with the
              contracting authority before submitting bids. If you believe this record contains inaccurate
              information, please{' '}
              <a
                href="mailto:corrections@akilibrain.com"
                className="text-primary hover:underline underline-offset-4"
              >
                contact our editorial team
              </a>.
            </p>
            <p className="text-xs text-muted-foreground/60 pt-1">
              Source: AkiliBrain Procurement Intelligence — aggregated daily from PPRA, PPIP, PPDA, RPPA and other official East African portals.
            </p>
          </section>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          <div className="bg-card border border-white/10 rounded-xl p-6 space-y-6 sticky top-24">
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Contracting Authority</p>
              <p className="font-medium flex items-start gap-2">
                <Building2 className="w-4 h-4 mt-0.5 shrink-0 text-primary" />
                <span>{tender.contractingAuthority}</span>
              </p>
            </div>

            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Location</p>
              <p className="font-medium flex items-center gap-2">
                <MapPin className="w-4 h-4 shrink-0 text-primary" />
                <span>{country || 'Unknown'}</span>
              </p>
            </div>

            {tender.budget && (
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Estimated Budget</p>
                <p className="font-medium text-emerald-400 flex items-center gap-2 text-lg">
                  <DollarSign className="w-5 h-5 shrink-0" />
                  <span>{tender.currency} {Number(tender.budget).toLocaleString()}</span>
                </p>
              </div>
            )}

            <div className="space-y-1 pt-4 border-t border-white/10">
              <p className="text-sm text-muted-foreground">Deadline</p>
              {tender.deadline ? (
                <>
                  <p className={`font-semibold flex items-center gap-2 text-lg ${isExpired ? 'text-destructive/80' : 'text-amber-400'}`}>
                    <Calendar className="w-5 h-5 shrink-0" />
                    {format(tender.deadline, 'PPP')}
                  </p>
                  <p className="text-xs text-muted-foreground pl-7">
                    {format(tender.deadline, 'p')}
                  </p>
                </>
              ) : (
                <p className="font-semibold flex items-center gap-2 text-lg text-muted-foreground">
                  <Calendar className="w-5 h-5 shrink-0" />
                  Not specified
                </p>
              )}
            </div>

            <div className="pt-6 space-y-3">
              {isExpired && (
                <div className="w-full text-center py-2 text-sm font-semibold text-destructive bg-destructive/10 border border-destructive/20 rounded-md">
                  Expired / Closed
                </div>
              )}
              {(tender.employerUrl ?? tender.sourceUrl) && (
                <a 
                  href={`/api/out?url=${encodeURIComponent(tender.employerUrl ?? tender.sourceUrl!)}&type=tender&id=${tender.id}`} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className={buttonVariants({ className: "w-full" })}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  {provenance.actionText}
                </a>
              )}
              {tender.documentUrl && (
                <a 
                  href={tender.documentUrl} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className={buttonVariants({ variant: "secondary", className: "w-full" })}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Document
                </a>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
