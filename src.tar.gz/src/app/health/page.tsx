import { db, safeQuery } from '@/lib/db/client';
import { healthDataPoints, healthIndicators } from '@/lib/db/schema/health';
import { countries } from '@/lib/db/schema/shared';
import { eq, desc, ilike, and, count } from 'drizzle-orm';
import { HealthCard } from '@/components/health/HealthCard';
import { buttonVariants } from '@/components/ui/button';
import { Activity, MapPin, Globe } from 'lucide-react';
import Link from 'next/link';
import { JsonLd } from '@/components/seo/JsonLd';
import { buildDatasetSchema, buildBreadcrumbSchema } from '@/components/seo/schemas';
import { GlobalFilterBar } from '@/components/shared/GlobalFilterBar';
import { parseGlobalSearchParams } from '@/lib/filters';

export const dynamic = 'force-dynamic';

import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Public Health Data Explorer',
  description:
    'Explore interactive East Africa health data, clinical trends, and DHIS2 analytics across Kenya, Tanzania, Uganda, Rwanda, Ethiopia, and DRC.',
  keywords: [
    'public health data Africa',
    'DHIS2 data Kenya',
    'health indicators East Africa',
    'WHO Africa statistics',
    'maternal health Kenya',
    'child health Tanzania',
    'disease surveillance Africa',
    'health dashboard East Africa',
  ],
  openGraph: {
    title: 'Public Health Data Explorer',
    description:
      'Explore interactive East Africa health data, clinical trends, and DHIS2 analytics across Kenya, Tanzania, Uganda, Rwanda, Ethiopia, and DRC.',
    url: 'https://akilibrain.com/health',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Public Health Data Explorer',
    description: 'Track key health indicators and disease statistics across East Africa.',
  },
  alternates: {
    canonical: 'https://akilibrain.com/health',
  },
};

import { unstable_cache } from 'next/cache';

const getUniqueCountries = unstable_cache(async () => {
  const uniqueCountriesData = await safeQuery(
    db.selectDistinct({ name: countries.name })
      .from(healthDataPoints)
      .innerJoin(countries, eq(healthDataPoints.countryId, countries.id))
  );
  return uniqueCountriesData.map(c => c.name).filter((c): c is string => Boolean(c)).sort();
}, ['health-unique-countries'], { revalidate: 3600 });

export default async function HealthPage({
  searchParams: rawParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const params = parseGlobalSearchParams(await rawParams);
  const q = params.q || '';
  const category = params.category || 'all';
  const country = params.country || 'all';
  const source = params.source || 'all';
  const page = params.page || 1;
  const PAGE_SIZE = 24;
  const offset = (page - 1) * PAGE_SIZE;
  
  const uniqueCountriesList = await getUniqueCountries();
  
  const conditions = [
    q ? ilike(healthIndicators.name, `%${q}%`) : undefined,
    category && category !== 'all' ? eq(healthIndicators.category, category) : undefined,
    country && country !== 'all' ? ilike(countries.name, `%${country}%`) : undefined,
    source && source !== 'all' ? ilike(healthDataPoints.source, `%${source}%`) : undefined,
  ].filter(Boolean);

  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

  const totalCountResult = await safeQuery(
    db.select({ value: count() })
      .from(healthDataPoints)
      .innerJoin(healthIndicators, eq(healthDataPoints.indicatorId, healthIndicators.id))
      .innerJoin(countries, eq(healthDataPoints.countryId, countries.id))
      .where(whereClause)
  );
  const totalCount = totalCountResult?.[0]?.value || 0;

  const data = await safeQuery(db
    .select({
      dataPoint: healthDataPoints,
      indicator: healthIndicators,
      country: countries.name,
    })
    .from(healthDataPoints)
    .innerJoin(healthIndicators, eq(healthDataPoints.indicatorId, healthIndicators.id))
    .innerJoin(countries, eq(healthDataPoints.countryId, countries.id))
    .where(whereClause)
    .orderBy(desc(healthDataPoints.year), desc(healthDataPoints.createdAt))
    .limit(PAGE_SIZE)
    .offset(offset));

  const datasetSchema = buildDatasetSchema({
    name: 'East Africa Public Health Indicators',
    description:
      'Aggregated public health data points including maternal health, child health, infectious disease, and mortality statistics across Kenya, Tanzania, Uganda, Rwanda, and Ethiopia. Sourced from DHIS2, WHO, and World Bank.',
    url: 'https://akilibrain.com/health',
    keywords: [
      'public health Africa', 'DHIS2', 'health indicators East Africa',
      'maternal health', 'child health', 'disease surveillance',
    ],
    creator: 'DHIS2 / WHO / World Bank / National Health Ministries',
    dateModified: new Date().toISOString().split('T')[0],
  });

  const breadcrumbSchema = buildBreadcrumbSchema([
    { name: 'Home', url: 'https://akilibrain.com' },
    { name: 'Public Health Data Explorer', url: 'https://akilibrain.com/health' },
  ]);

  const getPageUrl = (newPage: number) => {
    const sp = new URLSearchParams();
    if (q) sp.set('q', q);
    if (category && category !== 'all') sp.set('category', category);
    if (country && country !== 'all') sp.set('country', country);
    if (source && source !== 'all') sp.set('source', source);
    if (newPage > 1) sp.set('page', newPage.toString());
    const qs = sp.toString();
    return `/health${qs ? `?${qs}` : ''}`;
  };

  return (
    <div className="container py-8 max-w-7xl mx-auto space-y-8">
      <JsonLd schema={datasetSchema} />
      <JsonLd schema={breadcrumbSchema} />
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 border-b border-white/10 pb-6">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Public Health Data</h1>
          <p className="text-muted-foreground text-lg max-w-2xl">
            Track key health indicators, disease statistics, and health outcomes across Africa.
          </p>
        </div>
      </div>

      <GlobalFilterBar
        filters={[
          {
            id: 'q',
            type: 'search',
            label: 'Search Indicators',
            placeholder: 'Search indicators...',
          },
          {
            id: 'country',
            type: 'select',
            label: 'Location',
            icon: <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none z-10" />,
            options: [
              { value: 'all', label: 'All Locations' },
              ...uniqueCountriesList.map(c => ({ value: c, label: c }))
            ],
            defaultValue: 'all'
          },
          {
            id: 'source',
            type: 'select',
            label: 'Data Source',
            icon: <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none z-10" />,
            options: [
              { value: 'all', label: 'All Sources' },
              { value: 'dhis2', label: 'DHIS2' },
              { value: 'who', label: 'WHO' },
              { value: 'world bank', label: 'World Bank' },
              { value: 'national', label: 'National Ministry' },
            ],
            defaultValue: 'all'
          },
          {
            id: 'category',
            type: 'pills',
            options: [
              { value: 'all', label: 'All Categories' },
              { value: 'maternal', label: 'Maternal' },
              { value: 'child', label: 'Child' },
              { value: 'infectious', label: 'Infectious' },
              { value: 'mortality', label: 'Mortality' },
            ],
            defaultValue: 'all',
          },
        ]}
      />

      {totalCount > 0 && (
        <div className="flex justify-center -mt-4 mb-8">
          <div className="inline-flex items-center rounded-full border border-white/10 bg-white/5 px-3 py-1 text-sm font-medium text-white/70">
            Showing <span className="text-white mx-1">{data.length}</span> of <span className="text-white mx-1">{totalCount}</span> health data records
          </div>
        </div>
      )}

      {/* Grid */}
      {data.length === 0 ? (
        <>
          <div className="flex flex-col items-center justify-center py-16 px-4 text-center border border-white/10 rounded-xl bg-white/5 border-dashed">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4">
              <Activity className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Health data coming soon</h3>
            <p className="text-muted-foreground max-w-md">
              We are actively importing public health indicators from DHIS2, WHO AFRO, World Bank, and national health ministries across East Africa. Check back soon.
            </p>
            {(q || (category && category !== 'all') || (country && country !== 'all') || (source && source !== 'all')) && (
              <Link href="/health" className={buttonVariants({ variant: "outline", className: "mt-6" })}>
                Clear all filters
              </Link>
            )}
          </div>

          {/* SEO-rich static content for Googlebot when DB is empty */}
          <section className="mt-12 space-y-8 text-muted-foreground">
            <div className="border border-white/10 rounded-xl p-6 bg-white/5">
              <h2 className="text-xl font-bold text-foreground mb-3">About the Public Health Data Explorer</h2>
              <p className="leading-relaxed">
                AkiliBrain&apos;s Health Data module aggregates public health statistics from <strong>DHIS2</strong> (District Health Information Software), the <strong>World Health Organization (WHO)</strong>, the <strong>World Bank</strong>, and official national health ministries across Kenya, Tanzania, Uganda, Rwanda, and the DRC. Our goal is to make Africa&apos;s public health data accessible, searchable, and comparable in one place.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border border-white/10 rounded-xl p-6 bg-white/5">
                <h2 className="text-lg font-semibold text-foreground mb-2">Health Indicators Tracked</h2>
                <ul className="space-y-1 text-sm list-disc list-inside">
                  <li>Maternal mortality ratio (per 100,000 live births)</li>
                  <li>Under-5 child mortality rate</li>
                  <li>HIV/AIDS prevalence and treatment coverage</li>
                  <li>Malaria incidence per 1,000 population</li>
                  <li>Tuberculosis detection and treatment rates</li>
                  <li>Immunization coverage (DPT3, measles, polio)</li>
                  <li>Skilled birth attendance rates</li>
                  <li>Antenatal care (ANC) visit coverage</li>
                </ul>
              </div>
              <div className="border border-white/10 rounded-xl p-6 bg-white/5">
                <h2 className="text-lg font-semibold text-foreground mb-2">Data Sources</h2>
                <ul className="space-y-1 text-sm list-disc list-inside">
                  <li><strong>Kenya:</strong> DHIS2 Kenya — Ministry of Health</li>
                  <li><strong>Tanzania:</strong> DHIS2 Tanzania — MoHCDGEC</li>
                  <li><strong>Uganda:</strong> DHIS2 Uganda — Ministry of Health</li>
                  <li><strong>Rwanda:</strong> DHIS2 Rwanda — Ministry of Health</li>
                  <li><strong>DRC:</strong> Ministry of Public Health / WHO</li>
                  <li><strong>Global:</strong> WHO Global Health Observatory &amp; World Bank</li>
                </ul>
              </div>
            </div>
          </section>
        </>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {data.map(({ dataPoint, indicator, country }) => (
              <HealthCard
                key={dataPoint.id}
                id={dataPoint.id}
                indicatorName={indicator.name}
                category={indicator.category || 'General'}
                country={country || 'Unknown'}
                value={Number(dataPoint.value)}
                unit={indicator.unit || ''}
                year={dataPoint.year}
                source={dataPoint.source || 'DHIS2'}
                updatedAt={dataPoint.createdAt}
              />
            ))}
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-center gap-4 pt-6 border-t border-white/5 mt-8">
            {page > 1 && (
              <Link
                href={getPageUrl(page - 1)}
                className={buttonVariants({ variant: 'outline' })}
              >
                ← Previous
              </Link>
            )}
            <span className="text-sm text-muted-foreground">Page {page}</span>
            {offset + data.length < totalCount && (
              <Link
                href={getPageUrl(page + 1)}
                className={buttonVariants({ variant: 'outline' })}
              >
                Next →
              </Link>
            )}
          </div>
        </>
      )}
    </div>
  );
}
