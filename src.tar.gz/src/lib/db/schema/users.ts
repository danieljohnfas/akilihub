import { pgTable, text, timestamp, uuid, boolean, pgEnum, uniqueIndex, index } from 'drizzle-orm/pg-core';
import { countries, regions } from './shared';

export const alertFrequencyEnum = pgEnum('alert_frequency', ['immediate', 'daily', 'weekly']);

export const users = pgTable('users', {
  id: uuid('id').primaryKey(), // matches Supabase Auth UID
  email: text('email').notNull().unique(),
  fullName: text('full_name'),
  countryId: uuid('country_id').references(() => countries.id),
  regionId: uuid('region_id').references(() => regions.id),
  isPro: boolean('is_pro').notNull().default(false),
  proExpiresAt: timestamp('pro_expires_at'),
  lastSeenAt: timestamp('last_seen_at'),
  lastSearchQuery: text('last_search_query'),
  emailUpdates: boolean('email_updates').notNull().default(true),
  welcomeEmailSent: boolean('welcome_email_sent').notNull().default(false),
  createdAt: timestamp('created_at').notNull().defaultNow(),
  updatedAt: timestamp('updated_at').notNull().defaultNow(),
}, (table) => [
  // Speeds up the sendWelcomeEmailsJob that runs every 15 minutes
  index('users_welcome_email_idx').on(table.welcomeEmailSent)
]);

export const userAlerts = pgTable('user_alerts', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  module: text('module').notNull(), // 'tenders' | 'compliance' | 'health' | 'salaries'
  keywords: text('keywords').array(),
  countryId: uuid('country_id').references(() => countries.id),
  regionId: uuid('region_id').references(() => regions.id),
  frequency: alertFrequencyEnum('frequency').notNull().default('daily'),
  isActive: boolean('is_active').notNull().default(true),
  lastSentAt: timestamp('last_sent_at'),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => [
  // Prevent duplicate alerts: one alert per (user, module, country) combination
  uniqueIndex('user_alerts_unique_idx').on(table.userId, table.module, table.countryId),
]);

export const bookmarkItemTypeEnum = pgEnum('bookmark_item_type', ['job', 'tender', 'guide']);

export const bookmarks = pgTable('bookmarks', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  itemType: bookmarkItemTypeEnum('item_type').notNull(),
  itemId: uuid('item_id').notNull(),
  createdAt: timestamp('created_at').notNull().defaultNow(),
}, (table) => [
  // Prevent duplicate bookmarks for the same item
  uniqueIndex('bookmarks_unique_idx').on(table.userId, table.itemType, table.itemId),
]);